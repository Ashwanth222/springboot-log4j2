package com.bezkoder.spring.data.jpa.pagingsorting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaPagingSortingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaPagingSortingApplication.class, args);
	}

}
